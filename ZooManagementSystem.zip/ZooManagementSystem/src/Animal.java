
abstract class Animal {
    String name;
    int age;
    double weight;
    int ability;

    public void makeSound() {

        System.out.println("This animal is now making noise...");

    }

    public void eat() {
        System.out.println("This animal is now eating...");
    }

    public void sleep() {
        System.out.println("This animal is now sleeping...");

    }

    public void checkAbility() {

    }
}
