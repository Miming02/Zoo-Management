public class Primate extends Mammal {

    public Primate(String name, int age, double weight, int ability) {
        super(name, age, weight, ability);

    }

}
